package com.moviebox.app.data

import com.google.gson.annotations.SerializedName

// ── TMDB Config ────────────────────────────────────────────────
// APNI FREE TMDB KEY YAHAN DAALO: https://www.themoviedb.org/settings/api
const val TMDB_API_KEY  = "APNI_KEY_YAHAN_LIKHO"
const val BASE_URL      = "https://api.themoviedb.org/3/"
const val IMG_W500      = "https://image.tmdb.org/t/p/w500"
const val IMG_ORIGINAL  = "https://image.tmdb.org/t/p/original"
const val IMG_SMALL     = "https://image.tmdb.org/t/p/w92"

// ── Categories ─────────────────────────────────────────────────
data class Category(val label: String, val endpoint: String, val genreId: Int? = null)

val CATEGORIES = listOf(
    Category("🔥 Trending",    "trending/movie/week"),
    Category("⭐ Top Rated",   "movie/top_rated"),
    Category("🎬 Now Playing", "movie/now_playing"),
    Category("🚀 Upcoming",    "movie/upcoming"),
    Category("💥 Action",      "discover/movie", 28),
    Category("😂 Comedy",      "discover/movie", 35),
    Category("😱 Horror",      "discover/movie", 27),
    Category("💘 Romance",     "discover/movie", 10749),
    Category("🧠 Sci-Fi",      "discover/movie", 878),
    Category("🎭 Drama",       "discover/movie", 18),
)

// ── Response Models ────────────────────────────────────────────
data class MovieListResponse(
    @SerializedName("results") val results: List<Movie> = emptyList()
)

data class Movie(
    @SerializedName("id")            val id: Int = 0,
    @SerializedName("title")         val title: String = "",
    @SerializedName("overview")      val overview: String = "",
    @SerializedName("poster_path")   val posterPath: String? = null,
    @SerializedName("backdrop_path") val backdropPath: String? = null,
    @SerializedName("vote_average")  val voteAverage: Double = 0.0,
    @SerializedName("vote_count")    val voteCount: Int = 0,
    @SerializedName("release_date")  val releaseDate: String = "",
    @SerializedName("runtime")       val runtime: Int? = null,
    @SerializedName("tagline")       val tagline: String? = null,
    @SerializedName("genres")        val genres: List<Genre>? = null,
    @SerializedName("credits")       val credits: Credits? = null,
    @SerializedName("videos")        val videos: VideoResult? = null,
) {
    val posterUrl:   String? get() = posterPath?.let   { "$IMG_W500$it" }
    val backdropUrl: String? get() = backdropPath?.let { "$IMG_ORIGINAL$it" }
    val year:        String  get() = releaseDate.take(4)
}

data class Genre(
    @SerializedName("id")   val id: Int = 0,
    @SerializedName("name") val name: String = ""
)

data class Credits(
    @SerializedName("cast") val cast: List<CastMember> = emptyList(),
    @SerializedName("crew") val crew: List<CrewMember> = emptyList()
)

data class CastMember(
    @SerializedName("id")           val id: Int = 0,
    @SerializedName("name")         val name: String = "",
    @SerializedName("character")    val character: String = "",
    @SerializedName("profile_path") val profilePath: String? = null,
) { val profileUrl: String? get() = profilePath?.let { "$IMG_SMALL$it" } }

data class CrewMember(
    @SerializedName("id")   val id: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("job")  val job: String = ""
)

data class VideoResult(
    @SerializedName("results") val results: List<Video> = emptyList()
)

data class Video(
    @SerializedName("key")  val key: String = "",
    @SerializedName("type") val type: String = "",
    @SerializedName("site") val site: String = ""
) { val isTrailer: Boolean get() = type == "Trailer" && site == "YouTube" }
