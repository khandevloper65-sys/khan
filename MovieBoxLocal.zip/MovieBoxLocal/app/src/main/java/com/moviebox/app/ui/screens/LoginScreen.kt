package com.moviebox.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "t")
    val time by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI.toFloat()),
        animationSpec = infiniteRepeatable(
            tween(6000, easing = LinearEasing),
            RepeatMode.Restart
        ), label = "time"
    )

    Box(Modifier.fillMaxSize().background(Color(0xFF090910))) {

        // Live sunset canvas
        Canvas(Modifier.fillMaxSize()) { drawSunset(time) }

        // Overlay
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0x08000000), Color(0x66000010)))
        ))

        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo
            Text("🎬", fontSize = 64.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "MovieBox",
                fontSize = 50.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFFFCC44),
                style = LocalTextStyle.current.copy(
                    shadow = Shadow(Color(0x99FF8800), Offset(0f, 4f), 20f)
                )
            )
            Text(
                "CINEMA KA ASLI GHAR",
                fontSize = 12.sp,
                color = Color(0xCCFFE6B4),
                letterSpacing = 3.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(Modifier.height(48.dp))

            // Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xB2050819),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Swagat Hai! 🙏",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Login karo aur duniya bhar ki movies dekho",
                        fontSize = 14.sp,
                        color = Color(0xB3FFD296),
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(28.dp))

                    Button(
                        onClick = onLogin,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1877F2)),
                        elevation = ButtonDefaults.buttonElevation(8.dp)
                    ) {
                        Text("f ", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("Continue with Facebook", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(Modifier.height(20.dp))
                    Text(
                        "Login hokar apni movies save karo ✨",
                        fontSize = 12.sp,
                        color = Color(0x33FFFFFF),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(32.dp))
            Text(
                "Powered by TMDB • Made with ❤️",
                fontSize = 11.sp,
                color = Color(0x66FFC864),
                letterSpacing = 1.5.sp
            )
        }
    }
}

private fun DrawScope.drawSunset(t: Float) {
    val W = size.width
    val H = size.height

    // Sky
    drawRect(
        Brush.verticalGradient(
            listOf(Color(0xFF0A0A1F), Color(0xFF1A0A30), Color(0xFF4A1A08), Color(0xFFCC6600), Color(0xFFFF4400)),
            endY = H * 0.72f
        ),
        size = Size(W, H * 0.72f)
    )

    // Stars
    repeat(25) { i ->
        val a = ((sin(t * 2f + i) + 1f) / 2f) * 0.5f
        drawCircle(Color.White.copy(alpha = a), 1.2f, Offset((i * 137.5f) % W, (i * 89.3f) % (H * 0.32f)))
    }

    // Sun glow layers
    val sunY = H * 0.42f + sin(t) * 10f
    val sunR = minOf(W, H) * 0.08f
    listOf(3.0f to 0.12f, 2.2f to 0.18f, 1.6f to 0.25f).forEach { (m, a) ->
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFF000000 or (((a * 255).toInt()) shl 24) or 0xFFC840),
                    Color(0x00FF6400)),
                Offset(W / 2f, sunY), sunR * m
            ),
            sunR * m, Offset(W / 2f, sunY)
        )
    }

    // Sun disk
    drawCircle(
        Brush.radialGradient(
            listOf(Color(0xFFFFFDE0), Color(0xFFFFDD55), Color(0xFFFF9920), Color(0xFFFF5500)),
            Offset(W / 2f, sunY - sunR * 0.2f), sunR
        ),
        sunR, Offset(W / 2f, sunY)
    )

    // Horizon glow
    drawRect(
        Brush.verticalGradient(
            listOf(Color(0x88FF7814), Color(0x00B42800)),
            startY = H * 0.60f, endY = H * 0.72f
        ),
        Offset(0f, H * 0.60f), Size(W, H * 0.12f)
    )

    // Land silhouette
    val land = Path().apply {
        moveTo(0f, H * 0.73f)
        cubicTo(W * 0.25f, H * 0.68f, W * 0.5f, H * 0.71f, W * 0.75f, H * 0.69f)
        cubicTo(W * 0.88f, H * 0.68f, W * 0.95f, H * 0.70f, W, H * 0.71f)
        lineTo(W, H * 0.75f); lineTo(0f, H * 0.75f); close()
    }
    drawPath(land, Color(0xE5050814))

    // Water
    drawRect(
        Brush.verticalGradient(listOf(Color(0xF20A143C), Color(0xFF02081E)), startY = H * 0.68f, endY = H),
        Offset(0f, H * 0.68f), Size(W, H - H * 0.68f)
    )

    // Waves - 4 layers
    listOf(
        Triple(H * 0.68f + 12f, 0.013f, 0.22f),
        Triple(H * 0.68f + 32f, 0.010f, 0.16f),
        Triple(H * 0.68f + 58f, 0.008f, 0.11f),
        Triple(H * 0.68f + 95f, 0.006f, 0.07f),
    ).forEach { (baseY, freq, alpha) ->
        val path = Path().apply {
            moveTo(0f, baseY)
            var x = 0f
            while (x <= W) {
                lineTo(x, baseY + sin(x * freq + t) * 11f + sin(x * freq * 1.7f - t * 0.6f) * 5f)
                x += 8f
            }
            lineTo(W, H); lineTo(0f, H); close()
        }
        drawPath(path, Color(0xFFFF8C3C).copy(alpha = alpha))
    }

    // Sun reflection
    val refl = Path().apply {
        val cx = W / 2f
        moveTo(cx - 28f, H * 0.68f); lineTo(cx + 28f, H * 0.68f)
        lineTo(cx + W * 0.13f, H); lineTo(cx - W * 0.13f, H); close()
    }
    drawPath(refl, Brush.verticalGradient(
        listOf(Color(0x88FFA01E), Color(0x08FF3C00)), startY = H * 0.68f, endY = H
    ))

    // Sparkles
    repeat(14) { i ->
        val px = (i / 14f) * W + sin(t * 1.5f + i) * 25f
        val py = H * 0.68f + 12f + sin(px * 0.014f + t) * 10f
        drawCircle(Color(0xFFFFF0B4).copy(alpha = ((sin(t * 2.5f + i * 1.3f) + 1f) / 2f) * 0.7f), 2f, Offset(px, py))
    }
}
