package com.moviebox.app.data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.QueryMap
import java.util.concurrent.TimeUnit

interface TmdbApi {
    @GET("{endpoint}")
    suspend fun getMovies(
        @Path("endpoint", encoded = true) endpoint: String,
        @Query("api_key") key: String = TMDB_API_KEY,
        @QueryMap params: Map<String, String> = emptyMap()
    ): MovieListResponse

    @GET("movie/{id}")
    suspend fun getDetail(
        @Path("id") id: Int,
        @Query("api_key") key: String = TMDB_API_KEY,
        @Query("append_to_response") append: String = "credits,videos"
    ): Movie

    @GET("search/movie")
    suspend fun search(
        @Query("query") query: String,
        @Query("api_key") key: String = TMDB_API_KEY
    ): MovieListResponse
}

object ApiClient {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    val api: TmdbApi = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(httpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(TmdbApi::class.java)
}

object MovieRepository {
    private val api = ApiClient.api

    suspend fun getMovies(cat: Category): List<Movie> {
        val params = if (cat.genreId != null)
            mapOf("with_genres" to cat.genreId.toString())
        else emptyMap()
        return api.getMovies(cat.endpoint, params = params).results
    }

    suspend fun getDetail(id: Int): Movie = api.getDetail(id)

    suspend fun search(query: String): List<Movie> = api.search(query).results
}
