package com.moviebox.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.moviebox.app.data.Movie

@Composable
fun MovieCard(movie: Movie, onClick: (Movie) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF111118))
            .clickable { onClick(movie) }
    ) {
        if (movie.posterUrl != null) {
            AsyncImage(
                model = movie.posterUrl,
                contentDescription = movie.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f)
            )
        } else {
            Box(
                Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(Color(0xFF1A1A2E)),
                contentAlignment = Alignment.Center
            ) { Text("🎬", fontSize = 28.sp) }
        }

        // Gradient
        Box(
            Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(
                Brush.verticalGradient(
                    listOf(Color.Transparent, Color(0xDD000000)),
                    startY = 180f
                )
            )
        )

        // Rating
        Box(
            Modifier.align(Alignment.TopEnd).padding(5.dp)
                .background(Color(0xBF000000), RoundedCornerShape(5.dp))
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Text("★ ${"%.1f".format(movie.voteAverage)}", color = Color(0xFFF5C518), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
        }

        // Title
        Column(Modifier.align(Alignment.BottomStart).padding(7.dp)) {
            Text(movie.title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 13.sp)
            if (movie.year.isNotEmpty())
                Text(movie.year, color = Color(0xFFAAAAAA), fontSize = 9.sp)
        }
    }
}
