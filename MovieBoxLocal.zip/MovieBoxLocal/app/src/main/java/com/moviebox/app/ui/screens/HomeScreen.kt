package com.moviebox.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moviebox.app.data.CATEGORIES
import com.moviebox.app.data.Movie
import com.moviebox.app.data.MovieRepository
import com.moviebox.app.ui.components.MovieCard
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(onMovieClick: (Movie) -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var movies by remember { mutableStateOf<List<Movie>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<Movie>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    fun load(i: Int) {
        scope.launch {
            loading = true; error = null
            try { movies = MovieRepository.getMovies(CATEGORIES[i]) }
            catch (e: Exception) { error = "Error: ${e.message}" }
            finally { loading = false }
        }
    }

    LaunchedEffect(tab) { load(tab) }

    LaunchedEffect(search) {
        searchJob?.cancel()
        if (search.isBlank()) { searchResults = emptyList(); return@LaunchedEffect }
        searchJob = launch {
            delay(400); searching = true
            try { searchResults = MovieRepository.search(search) } catch { searchResults = emptyList() }
            searching = false
        }
    }

    val list = if (search.isNotBlank()) searchResults else movies

    Column(Modifier.fillMaxSize().background(Color(0xFF090910))) {

        // Header
        Column(Modifier.background(Color(0xF2090910)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🎬", fontSize = 22.sp)
                Spacer(Modifier.width(8.dp))
                Text("MovieBox", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color(0xFFE63946))
            }
            Spacer(Modifier.height(10.dp))
            // Search
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(Color(0x12FFFFFF)).padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🔍", fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    cursorBrush = SolidColor(Color(0xFFE63946)),
                    singleLine = true,
                    decorationBox = { inner ->
                        if (search.isEmpty()) Text("Search movies...", color = Color(0xFF555555), fontSize = 14.sp)
                        inner()
                    }
                )
                if (search.isNotEmpty()) {
                    Text("✕", color = Color(0xFF666666), modifier = Modifier.clickable { search = "" }.padding(4.dp))
                }
            }
        }

        // Tabs
        if (search.isBlank()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CATEGORIES.forEachIndexed { i, cat ->
                    val active = tab == i
                    Box(
                        Modifier.clip(RoundedCornerShape(20.dp))
                            .background(
                                if (active) Brush.linearGradient(listOf(Color(0xFFE63946), Color(0xFFC1121F)))
                                else Brush.linearGradient(listOf(Color(0x12FFFFFF), Color(0x12FFFFFF)))
                            )
                            .clickable { tab = i }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text(cat.label, color = if (active) Color.White else Color(0xFF888888),
                            fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        } else {
            Text(
                if (searching) "Dhundh raha hoon..." else "\"$search\" — ${searchResults.size} results",
                color = Color(0xFF888888), fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        // Content
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Color(0xFFE63946), strokeWidth = 3.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("Movies la raha hoon...", color = Color(0xFF666666), fontSize = 13.sp)
                }
            }
            error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("😔", fontSize = 36.sp)
                    Text(error!!, color = Color(0xFFE63946), fontWeight = FontWeight.Bold)
                    Button(onClick = { load(tab) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE63946)),
                        shape = RoundedCornerShape(10.dp)
                    ) { Text("Dobara Try Karo", fontWeight = FontWeight.Bold) }
                }
            }
            list.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎭", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Koi film nahi mili", color = Color(0xFF555555))
                }
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(list, key = { it.id }) { MovieCard(it, onMovieClick) }
            }
        }
    }
}
