package com.moviebox.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.moviebox.app.data.Movie
import com.moviebox.app.data.MovieRepository
import kotlin.math.roundToInt

@Composable
fun DetailScreen(movieId: Int, initial: Movie, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var movie by remember { mutableStateOf(initial) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(movieId) {
        try { movie = MovieRepository.getDetail(movieId) } catch { }
        loading = false
    }

    val trailer = movie.videos?.results?.firstOrNull { it.isTrailer }
    val director = movie.credits?.crew?.firstOrNull { it.job == "Director" }
    val cast = movie.credits?.cast?.take(6) ?: emptyList()

    Box(Modifier.fillMaxSize().background(Color(0xFF0E0E16))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

            // Backdrop
            Box(Modifier.fillMaxWidth().height(270.dp)) {
                if (movie.backdropUrl != null) {
                    AsyncImage(model = movie.backdropUrl, contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Box(Modifier.fillMaxSize().background(Color(0xFF1A1A2E)), contentAlignment = Alignment.Center) {
                        Text("🎬", fontSize = 56.sp)
                    }
                }
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF0E0E16)), startY = 130f)
                ))
            }

            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(-50.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.Bottom) {
                    if (movie.posterUrl != null) {
                        AsyncImage(model = movie.posterUrl, contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.width(88.dp).height(132.dp).clip(RoundedCornerShape(12.dp)))
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 4.dp).weight(1f)) {
                        Text(movie.title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black, lineHeight = 25.sp)
                        if (!movie.tagline.isNullOrBlank())
                            Text("\"${movie.tagline}\"", color = Color(0xFF888888), fontSize = 12.sp, fontStyle = FontStyle.Italic)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            movie.genres?.take(3)?.forEach { g ->
                                Box(Modifier.background(Color(0x2EA78BFA), RoundedCornerShape(6.dp)).padding(horizontal = 7.dp, vertical = 2.dp)) {
                                    Text(g.name, color = Color(0xFFA78BFA), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        StarsRow(movie.voteAverage)
                        val meta = buildString {
                            if (movie.year.isNotEmpty()) append(movie.year)
                            movie.runtime?.let { append(" • $it min") }
                            if (movie.voteCount > 0) append(" • ${"%,d".format(movie.voteCount)} votes")
                        }
                        if (meta.isNotEmpty()) Text(meta, color = Color(0xFF666666), fontSize = 10.sp)
                    }
                }

                Spacer(Modifier.height(18.dp))
                if (movie.overview.isNotBlank())
                    Text(movie.overview, color = Color(0xFFCCCCCC), fontSize = 14.sp, lineHeight = 22.sp)

                if (director != null) {
                    Spacer(Modifier.height(18.dp))
                    Text("DIRECTOR", color = Color(0xFF555555), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(director.name, color = Color(0xFFEEEEEE), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                if (cast.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    Text("CAST", color = Color(0xFF555555), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        cast.forEach { c ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(60.dp)) {
                                if (c.profileUrl != null) {
                                    AsyncImage(model = c.profileUrl, contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(50.dp).clip(CircleShape))
                                } else {
                                    Box(Modifier.size(50.dp).clip(CircleShape).background(Color(0xFF333333)), contentAlignment = Alignment.Center) {
                                        Text("👤", fontSize = 18.sp)
                                    }
                                }
                                Spacer(Modifier.height(5.dp))
                                Text(c.name, color = Color(0xFFDDDDDD), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 13.sp)
                                Text(c.character, color = Color(0xFF666666), fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }

                if (trailer != null) {
                    Spacer(Modifier.height(22.dp))
                    Button(
                        onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/watch?v=${trailer.key}"))) },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE63946)),
                        elevation = ButtonDefaults.buttonElevation(8.dp)
                    ) { Text("▶  Trailer Dekho", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
                }

                Spacer(Modifier.height(40.dp))
            }
        }

        // Back button
        Box(Modifier.padding(top = 42.dp, start = 10.dp).background(Color(0x99000000), RoundedCornerShape(20.dp))) {
            TextButton(onClick = onBack) {
                Text("← Back", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        if (loading) {
            Box(Modifier.fillMaxSize().background(Color(0x33000000)), Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFE63946))
            }
        }
    }
}

@Composable
private fun StarsRow(rating: Double) {
    val filled = ((rating / 10.0) * 5).roundToInt()
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(5) { i -> Text("★", color = if (i < filled) Color(0xFFF5C518) else Color(0xFF333333), fontSize = 13.sp) }
        Spacer(Modifier.width(4.dp))
        Text("${"%.1f".format(rating)}/10", color = Color(0xFFAAAAAA), fontSize = 11.sp)
    }
}
