package com.moviebox.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat
import com.moviebox.app.data.Movie
import com.moviebox.app.ui.screens.DetailScreen
import com.moviebox.app.ui.screens.HomeScreen
import com.moviebox.app.ui.screens.LoginScreen

sealed class Screen {
    object Login : Screen()
    object Home : Screen()
    data class Detail(val movie: Movie) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            var screen by remember { mutableStateOf<Screen>(Screen.Login) }
            when (val s = screen) {
                is Screen.Login  -> LoginScreen(onLogin = { screen = Screen.Home })
                is Screen.Home   -> HomeScreen(onMovieClick = { screen = Screen.Detail(it) })
                is Screen.Detail -> DetailScreen(s.movie.id, s.movie, onBack = { screen = Screen.Home })
            }
        }
    }
}
