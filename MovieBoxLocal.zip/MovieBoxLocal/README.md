# 🎬 MovieBox — Pure Kotlin Android Project
# Local Gradle se build hota hai — gradlew wrapper NAHI chahiye

## Termux PRoot Ubuntu me build karna

### Step 1 — Dependencies install karo
```bash
apt update
apt install -y openjdk-17-jdk gradle android-sdk
# Ya agar openjdk-17 nahi hai:
apt install -y openjdk-11-jdk gradle
```

### Step 2 — Android SDK setup
```bash
export ANDROID_HOME=/usr/lib/android-sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### Step 3 — TMDB API Key daalo
```bash
nano app/src/main/java/com/moviebox/app/data/Models.kt
# APNI_KEY_YAHAN_LIKHO ko apni key se badlo
# Free key: https://www.themoviedb.org/settings/api
```

### Step 4 — Build karo (LOCAL GRADLE — no wrapper!)
```bash
cd MovieBoxLocal

# Debug APK
gradle assembleDebug

# Ya specific version ke saath
gradle-7.4 assembleDebug
# Ya
gradle-8.0 assembleDebug
```

### Step 5 — APK kahan milegi
```
app/build/outputs/apk/debug/app-debug.apk
```

## Android Studio me kholna
1. File → Open → MovieBoxLocal folder
2. Models.kt me TMDB key daalo
3. Run ▶

## File Structure
```
MovieBoxLocal/
├── build.gradle          ← Root (AGP 7.4.2 + Kotlin 1.8.22)
├── settings.gradle
├── gradle.properties     ← PRoot ke liye optimize
└── app/
    ├── build.gradle      ← compileSdk 33, stable deps
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/moviebox/app/
        │   ├── MainActivity.kt
        │   ├── data/
        │   │   ├── Models.kt       ← TMDB key yahan daalo
        │   │   └── Repository.kt
        │   └── ui/
        │       ├── screens/
        │       │   ├── LoginScreen.kt   (sunset animation)
        │       │   ├── HomeScreen.kt    (movie grid + search)
        │       │   └── DetailScreen.kt  (detail + trailer)
        │       └── components/
        │           └── MovieCard.kt
        └── res/values/themes.xml
```

## Agar error aaye
```bash
# Memory error pe:
export GRADLE_OPTS="-Xmx1024m"
gradle assembleDebug

# Java version check:
java -version  # 11 ya 17 hona chahiye

# Cache clear karke try karo:
gradle clean
gradle assembleDebug
```
